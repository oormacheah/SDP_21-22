The kit includes files involved in handling pid/waitpid and sys__exit.
A solution, though incomplete/preliminary (but working), is also proposed for fork (notice that testbed/forktest requires getpid).
